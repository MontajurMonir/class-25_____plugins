/**!
 * {{title}} v{{version}}
 * {{description}}
 * Build {{buildId}}
 *
 * Requires mixitup.js >= v{{coreVersion}}
 *
 * @copyright Copyright {{beginCopyrightYear}}-{{currentYear}} {{author}}.
 * @author    {{author}}.
 * @link      {{websiteUrl}}
 * @license   Apache-2.0
 */
